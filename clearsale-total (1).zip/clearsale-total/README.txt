=== ClearSale Total ===
Contributors: Letti Tecnologia - https://letti.com.br
Donate link: 
Tags: e-commerce, woocommerce, sell, store, shop, clearsale, antifraude, análise por inteligência artificial, equipe de detecção de fraude, cartão de crédito
Requires at least: 4.4
Tested up to: 6.2
Stable tag: 3.0.14
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Integração do WooCommerce com a ClearSale.
testado: wordpress 6.2
woocommerce 7.6
Requisitos:
php 5.5.3 ou maior

== Description ==

Esta solução implementa a verificação de fraude em toda compra feita por esta loja, muitos plugins de formas de pagamentos estão integrados, possibilitando levar os dados do cartão de crédito junto com o pedido para aprimorar a análise.
Todo pedido incluído na ClearSale recebe status de "Em Análise" e é salvo em "Notas" do pedido.
Após a análise o status é alterado, podendo o lojista consultar pelo Grid de pedidos ou no corpo do pedido.

== Installation ==

Certifique-se de que não há instalação de outros módulos da ClearSale em seu sistema;
Baixe o arquivo clearsale-total.zip;
Na área administrativa de seu WordPress acesse o menu Plugins -> Adicionar Novo -> Enviar/Fazer upload do plugin ->
->escolher arquivo, ache o caminho do arquivo clearsale-total.zip e selecione Instalar Agora;
Após a instalação selecione Ativar plugin;
[Clique aqui para tutorial on line](https://api.clearsale.com.br/docs/plugins/wooCommerce/totalTotalGarantidoApplication)

== Configurations ==

Para acessar "CONFIGURAÇÕES" do módulo acesse, na área administrativa de seu WordPress, Configurações -> ClearSale Total.
 
As opções disponíveis estão descritas abaixo.

    Selecione entre ambiente de teste e produção (Defina se está no modo homologação ou produção)

    Digite login e senha fornecidos pela ClearSale
 
    Digite o Fingerprint fornecido pela ClearSale, 
        Você deve ter um número parecido com este: a6s8h29ym6xgm5qor3sk

    Informar a URL que aparece no final da tela de configuração para a ClearSale, com isto a loja recebe as aprovações de compras analisadas.

[Veja a tela 10 do tutorial](https://api.clearsale.com.br/docs/plugins/wooCommerce/totalTotalGarantidoApplication#configuration-section)

== Frequently Asked Questions ==

[Aqui, em FAQ, temos as dúvidas mais frequentes](https://br.clear.sale/total)

== Screenshots ==

== Changelog ==
Para consultar o log de alterações acesse o arquivo [CHANGELOG.md](CHANGELOG.md).

== Arbitrary section ==

