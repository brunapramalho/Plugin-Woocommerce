

#xgettext -n --keyword=_e --keyword=esc_attr_e --keyword=__ -d clearsale -D admin -D includes *.php

#xgettext -n --keyword=_e --keyword=esc_attr_e --keyword=__ -d clearsale  *.php

xgettext -n --keyword=_e --keyword=esc_attr_e --keyword=__ --from-code=UTF-8 -d clearsale  *.php
