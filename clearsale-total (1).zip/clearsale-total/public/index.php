<?php // Silence is golden
/*
https://blog.apiki.com/2015/09/21/wordpress-nonces-e-o-que-voce-precisa-saber-sobre-isso/
https://tableless.com.br/requisicoes-ajax-no-wordpress/
https://codex.wordpress.org/AJAX_in_Plugins

*/
