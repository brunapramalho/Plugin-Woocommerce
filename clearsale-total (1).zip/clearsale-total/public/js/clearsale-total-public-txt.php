<?php
/*
Como pegar o click do botão fechar pedido do woocommerce
https://stackoverflow.com/questions/62133353/why-jquery-click-event-listener-isnt-registered-on-woocommerce-button

$('form.woocommerce-checkout').on( 'click', "#place_order", function(event){
    event.preventDefault(); // Disable submit for testing

    console.log("click");
    alert("click");
});

Não conseguimos pegar o nonce dentro do WP, o nonce se repete em compras seguidas. Não se pega o hash e o order_key
não existe ainda, só após o pedido.
var nonce = $('#woocommerce-process-checkout-nonce').val();
var hash = wc_cart_fragments_params.cart_hash_key;

Referrer não funciona, é a página anterior
var rfr = document.referrer;
console.log("quem chamou=" + rfr);// https://woo.letti.com.br/minha-conta/

Retirado do .js por não usar mais, métodos que pegamos pelo postmeta
		if (card == null) {
			console.log("Ajax:ClearSale:place_order:é Ipag?");
			card = $('#ipag_credito_card_num').val();
			var card_installments = $('#ipag_credito_installments').val();
			var card_holder = $('#ipag_credito_card_name').val();
			var cpf = $('#ipag_credito_card_cpf').val();
			//ipag_credito_card_expiry - formato = MM/AA
			var validate = $('#ipag_credito_card_expiry').val();
			metodo = 2; //ipag por Ipag V 2.1.4
		}
		if (card == null) {
			console.log("Ajax:ClearSale:place_order:é Rede MA?");
			card = $('#rede-card-number').val();
			card_holder = $('#rede-card-holder-name').val();
			var validate = $('#rede_credit_expiry').val();
			var card_installments = $('#rede_credit_installments').val();
			// CPF nao pede neste metodo
			metodo = 3; //rede por MarcosAlexandre  2.1.1
		}


metodos do Ajax: nome do plugin - onde achar - nome interno do metodo

1 = pagseguro oficial da UOL V 2.0.0 , rotina propria em js.

    Tem dados no post_meta, pego pelo método outrosMetodos
2 = ipag por Ipag V 2.1.4 - https://br.wordpress.org/plugins/ipag-woocommerce/
3 = rede por MarcosAlexandre  2.1.1 - https://br.wordpress.org/plugins/woo-rede/ - tipo=rede_credit
5 = loja5_woo_cielo_webservice - Integração de Pagamento ao Cielo API 3.0. Versão 4.0 | Por Loja5.com.br
    versão 5.0 testado na nossa loja.
7 = Loja5-e.Rede API de Pagtos para Cartões - V 3.0 - em 20/9/22
9 = Pagar-me pela Pagarme - Versão 2.0.14

	Nao tem dados no post_meta, salvamos no cs_total_dadosextras e pegos pelo ajax
4 = Gerencianet - Versão 1.4.7 - Gateway de pagamento Gerencianet para WooCommerce
6 = Iugu - Gateway de pagamento da iugu para WooCommerce. Versão 3.0.0.11 | Por iugu
    Boleto, PIX pelo payment_method o cartão por ajax
8 = PagSeguro Claudio Sanches - Crédito, débito e boleto



*/
