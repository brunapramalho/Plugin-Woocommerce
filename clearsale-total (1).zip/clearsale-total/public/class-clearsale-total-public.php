<?php
/**
 * The public-facing functionality of the plugin.
*/
/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Clearsale_Total
 * @subpackage Clearsale_Total/public
 * @author     Letti Tecnologia <contato@letti.com.br>
 */
class Clearsale_Total_Public
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->wp_cs_options = get_option($this->plugin_name);
//		$cs_status = new Clearsale_Status($plugin_name, $version);
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function cs_enqueue_styles()
	{

		/**
		 * 
		 * An instance of this class should be passed to the run() function
		 * defined in Clearsale_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Clearsale_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/clearsale-total-public.css', array(), $this->version, 'all');

	} // end of enqueue_styles

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function cs_enqueue_scripts()
	{

		/**
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Clearsale_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Clearsale_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/clearsale-total-public.js', array( 'jquery' ), $this->version, false);

	} // end of enqueue_scripts

	// other functions here

} // end of class
