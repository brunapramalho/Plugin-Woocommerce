<?php
/**
 * Deprecated! Não usado mais, usando APIs do Woocommerce.
 * 03/05/22
*/

header('Location: /wc-api/clearsale_total_status/');

die();
