<?php
/**
 * Provide a public-facing view for the plugin
 */
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://letti.com.br/wordpress
 * @since      1.0.0
 *
 * @package    Clearsale_Total
 * @subpackage Clearsale/_Totalpublic/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
